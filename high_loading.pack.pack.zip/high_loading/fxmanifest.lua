fx_version 'adamant'
game 'gta5'

author 'highrider#2873'
description 'High-Loading'
version '0.1'

files {
    '*.html',
    'assets/**/*.*',
    'assets/**/**/*.*'
}

loadscreen 'index.html'
dependency '/assetpacks'