/* highrider#2873 @ 2021 */
Config = {}; // Do not touch

Config.Buttons = [
    {
        "id": "about", // Button ID
        "label": "About", // Button label
        "default": true // On page load which button is pre-selected?
    },
    {
        "id": "contacts",
        "label": "Contacts",
        "default": false
    },
    {
        "id": "media",
        "label": "Media",
        "default": false
    },
] // Categories [on the top right corner in the left box], match the ID's with page ID's.

Config.Pages = [
    {
        "id": "about",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus com modo viverra maecenas accumsan lacus vel facilisis."
    },
    {
        "id": "contacts",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
        "additionalinfo": [
            {
                "icon": "discord.png", // In assets/media folder.
                "data": "<b>highrider</b>#2873"
            },
            {
                "icon": "discord.png", // In assets/media folder.
                "data": "<b>F1ESTA</b>#3871"
            }
        ]
    },
    {
        "id": "media",
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus com modo viverra maecenas accumsan lacus vel facilisis."
    }
] // Pages in the left screen box. "id" has to be set to one of the button's ID's, it'll open that page when you click on that button.

Config.MediaPage = "media" // The page in which you'll be able to see gallery and video.
Config.Images = [ // Gallery images, put them in assets/media/gallery folder.
    "1.png", // Obviously the first image will be the first image visible in the gallery on load.
    "2.png"
];